//
//  CursoCompletadoViewController.swift
//  BillRegistraCursos
//
//  Created by MAC01 on 24/04/18.
//  Copyright © 2018 Tecsup. All rights reserved.
//

import UIKit

class CursoCompletadoViewController: UIViewController {
    @IBOutlet weak var promPrac: UILabel!
    @IBOutlet weak var nomCurso: UILabel!
    @IBOutlet weak var promLab: UILabel!
    @IBOutlet weak var ExaFinal: UILabel!
    var curso:Curso? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        obtenerPromedio()
        obtenerNombre()
        obtenerLaboratorios()
        obtenerExamenFinal()
    }
    func obtenerPromedio(){
        promPrac.text = "\(curso!.pro_prac!)"
    }
    func obtenerLaboratorios(){
        promLab.text = "\(curso!.pro_lab!)"
    }
    func obtenerExamenFinal(){
        ExaFinal.text = "\(curso!.exa_final!)"
    }
    func obtenerNombre(){
            nomCurso.text = "🙀\(curso!.nom_curso!)"
    }
}
